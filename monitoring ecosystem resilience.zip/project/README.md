# Ecosystem Resilience Monitoring App

## Overview

A comprehensive mobile and web application for monitoring ecosystem resilience through vegetation and weather data analysis. Built with React Native and Expo, this application provides tools for data collection, processing, and analysis of ecosystem health indicators.

## Features

### 1. Configuration
- Location-based data collection setup
- Date range selection
- Resolution configuration
- Parameter customization

### 2. Data Processing
- Vegetation data collection and analysis
- Weather data integration
- Network centrality calculations
- Real-time processing status tracking

### 3. Analysis Tools
- Time series analysis
- Data preprocessing
- Statistical analysis
- Early Warning Signals (EWS) detection

## Technical Stack

- **Framework**: React Native + Expo SDK 52
- **Navigation**: Expo Router 4.0.17
- **UI Components**: Native components with custom styling
- **Icons**: Lucide React Native
- **State Management**: React Hooks
- **Data Visualization**: Custom charting components

## Project Structure

```
app/
├── _layout.tsx                 # Root layout configuration
├── +not-found.tsx             # 404 error handling
└── (tabs)/                    # Main navigation tabs
    ├── _layout.tsx            # Tab navigation configuration
    ├── index.tsx              # Configuration screen
    ├── process.tsx            # Data processing screen
    └── analyze.tsx            # Analysis dashboard
```

## Installation

1. Clone the repository
2. Install dependencies:
   ```bash
   npm install
   ```
3. Start the development server:
   ```bash
   npm run dev
   ```

## Usage Guide

### Configuration Tab
1. Enter location coordinates
2. Set date range for data collection
3. Configure resolution parameters
4. Generate configuration file

### Processing Tab
1. Monitor vegetation data processing
2. Track weather data integration
3. View network analysis progress
4. Check processing status

### Analysis Tab
1. Access data preprocessing tools
2. Run statistical analysis
3. Generate visualization
4. Export results

## Development Guidelines

### Code Style
- Use TypeScript for type safety
- Follow React Native best practices
- Implement proper error handling
- Maintain consistent styling

### Testing
- Unit tests for core functionality
- Integration tests for data processing
- UI component testing
- Performance benchmarking

## Contributing

1. Fork the repository
2. Create a feature branch
3. Submit a pull request
4. Follow code review process

## License

MIT License - See LICENSE file for details