import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { TrendingUp, Filter, Clock, Calculator } from 'lucide-react-native';

export default function AnalyzeScreen() {
  return (
    <ScrollView style={styles.container}>
      <View style={styles.content}>
        <Text style={styles.title}>Analysis</Text>
        <Text style={styles.description}>
          Analyze and visualize ecosystem data
        </Text>

        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <Filter size={24} color="#2563eb" />
            <Text style={styles.cardTitle}>Data Preprocessing</Text>
          </View>
          <Text style={styles.cardDescription}>
            Clean and prepare data for analysis
          </Text>
          <View style={styles.steps}>
            <Text style={styles.step}>• Remove outliers</Text>
            <Text style={styles.step}>• Fill gaps in data</Text>
            <Text style={styles.step}>• Apply deseasonalization</Text>
          </View>
        </View>

        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <TrendingUp size={24} color="#2563eb" />
            <Text style={styles.cardTitle}>Time Series Analysis</Text>
          </View>
          <Text style={styles.cardDescription}>
            Analyze temporal patterns and trends
          </Text>
          <View style={styles.steps}>
            <Text style={styles.step}>• Calculate moving averages</Text>
            <Text style={styles.step}>• Detect trends</Text>
            <Text style={styles.step}>• Identify seasonal patterns</Text>
          </View>
        </View>

        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <Calculator size={24} color="#2563eb" />
            <Text style={styles.cardTitle}>Statistical Analysis</Text>
          </View>
          <Text style={styles.cardDescription}>
            Calculate key ecosystem metrics
          </Text>
          <View style={styles.steps}>
            <Text style={styles.step}>• Compute EWS statistics</Text>
            <Text style={styles.step}>• Generate summary reports</Text>
            <Text style={styles.step}>• Export results</Text>
          </View>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  content: {
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1e293b',
    marginBottom: 8,
  },
  description: {
    fontSize: 16,
    color: '#64748b',
    marginBottom: 24,
  },
  card: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 6,
    elevation: 2,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1e293b',
    marginLeft: 12,
  },
  cardDescription: {
    fontSize: 14,
    color: '#64748b',
    marginBottom: 12,
  },
  steps: {
    paddingLeft: 8,
  },
  step: {
    fontSize: 14,
    color: '#475569',
    marginBottom: 4,
  },
});