import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { Download, Image as ImageIcon, CloudRain, Network } from 'lucide-react-native';

export default function ProcessScreen() {
  return (
    <ScrollView style={styles.container}>
      <View style={styles.content}>
        <Text style={styles.title}>Data Processing</Text>
        <Text style={styles.description}>
          Download and process vegetation and weather data
        </Text>

        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <ImageIcon size={24} color="#2563eb" />
            <Text style={styles.cardTitle}>Vegetation Data</Text>
          </View>
          <Text style={styles.cardDescription}>
            Download and process vegetation imagery for analysis
          </Text>
          <View style={styles.progressBar}>
            <View style={[styles.progressFill, { width: '0%' }]} />
          </View>
          <Text style={styles.progressText}>Not started</Text>
        </View>

        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <CloudRain size={24} color="#2563eb" />
            <Text style={styles.cardTitle}>Weather Data</Text>
          </View>
          <Text style={styles.cardDescription}>
            Retrieve and process weather information
          </Text>
          <View style={styles.progressBar}>
            <View style={[styles.progressFill, { width: '0%' }]} />
          </View>
          <Text style={styles.progressText}>Not started</Text>
        </View>

        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <Network size={24} color="#2563eb" />
            <Text style={styles.cardTitle}>Network Analysis</Text>
          </View>
          <Text style={styles.cardDescription}>
            Calculate network centrality metrics
          </Text>
          <View style={styles.progressBar}>
            <View style={[styles.progressFill, { width: '0%' }]} />
          </View>
          <Text style={styles.progressText}>Not started</Text>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  content: {
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1e293b',
    marginBottom: 8,
  },
  description: {
    fontSize: 16,
    color: '#64748b',
    marginBottom: 24,
  },
  card: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 6,
    elevation: 2,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1e293b',
    marginLeft: 12,
  },
  cardDescription: {
    fontSize: 14,
    color: '#64748b',
    marginBottom: 16,
  },
  progressBar: {
    height: 6,
    backgroundColor: '#e2e8f0',
    borderRadius: 3,
    marginBottom: 8,
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#2563eb',
    borderRadius: 3,
  },
  progressText: {
    fontSize: 14,
    color: '#64748b',
  },
});