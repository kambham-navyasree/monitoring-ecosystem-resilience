import { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, ScrollView, StyleSheet } from 'react-native';

export default function ConfigScreen() {
  const [config, setConfig] = useState({
    location: '',
    startDate: '',
    endDate: '',
    resolution: '',
  });

  const handleGenerate = () => {
    // TODO: Implement configuration generation
    console.log('Generating config:', config);
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.content}>
        <Text style={styles.title}>Configuration</Text>
        <Text style={styles.description}>
          Define parameters for vegetation and weather data collection
        </Text>

        <View style={styles.inputContainer}>
          <Text style={styles.label}>Location</Text>
          <TextInput
            style={styles.input}
            value={config.location}
            onChangeText={(text) => setConfig({ ...config, location: text })}
            placeholder="Enter coordinates (lat, long)"
          />
        </View>

        <View style={styles.inputContainer}>
          <Text style={styles.label}>Start Date</Text>
          <TextInput
            style={styles.input}
            value={config.startDate}
            onChangeText={(text) => setConfig({ ...config, startDate: text })}
            placeholder="YYYY-MM-DD"
          />
        </View>

        <View style={styles.inputContainer}>
          <Text style={styles.label}>End Date</Text>
          <TextInput
            style={styles.input}
            value={config.endDate}
            onChangeText={(text) => setConfig({ ...config, endDate: text })}
            placeholder="YYYY-MM-DD"
          />
        </View>

        <View style={styles.inputContainer}>
          <Text style={styles.label}>Resolution (meters)</Text>
          <TextInput
            style={styles.input}
            value={config.resolution}
            onChangeText={(text) => setConfig({ ...config, resolution: text })}
            placeholder="e.g., 10"
            keyboardType="numeric"
          />
        </View>

        <TouchableOpacity style={styles.button} onPress={handleGenerate}>
          <Text style={styles.buttonText}>Generate Configuration</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  content: {
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1e293b',
    marginBottom: 8,
  },
  description: {
    fontSize: 16,
    color: '#64748b',
    marginBottom: 24,
  },
  inputContainer: {
    marginBottom: 16,
  },
  label: {
    fontSize: 14,
    fontWeight: '500',
    color: '#475569',
    marginBottom: 6,
  },
  input: {
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: '#cbd5e1',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
  },
  button: {
    backgroundColor: '#2563eb',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 24,
  },
  buttonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '600',
  },
});