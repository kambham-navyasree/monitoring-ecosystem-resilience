# API Documentation

## Overview

This document details the internal APIs and components of the Ecosystem Resilience Monitoring application.

## Components

### ConfigurationScreen

```typescript
interface ConfigProps {
  location: string;
  startDate: string;
  endDate: string;
  resolution: string;
}

function ConfigurationScreen(): JSX.Element
```

Handles the initial setup and configuration of monitoring parameters.

### ProcessingMonitor

```typescript
interface ProcessStatus {
  vegetation: {
    status: 'pending' | 'processing' | 'complete';
    progress: number;
  };
  weather: {
    status: 'pending' | 'processing' | 'complete';
    progress: number;
  };
  network: {
    status: 'pending' | 'processing' | 'complete';
    progress: number;
  };
}

function ProcessingMonitor(): JSX.Element
```

Displays real-time processing status and progress.

### AnalysisTools

```typescript
interface AnalysisOptions {
  dropOutliers: boolean;
  fillGaps: boolean;
  deseasonalize: boolean;
  smoothing: {
    enabled: boolean;
    window: number;
  };
}

function AnalysisTools(): JSX.Element
```

Provides analysis and visualization capabilities.

## Hooks

### useDataProcessing

```typescript
function useDataProcessing(config: ConfigProps): {
  status: ProcessStatus;
  startProcessing: () => Promise<void>;
  cancelProcessing: () => void;
}
```

Manages data processing operations and status.

### useAnalysis

```typescript
function useAnalysis(options: AnalysisOptions): {
  results: AnalysisResults;
  analyze: () => Promise<void>;
  error: Error | null;
}
```

Handles data analysis operations.

## Types

```typescript
interface AnalysisResults {
  timeSeriesData: Array<{
    timestamp: string;
    value: number;
  }>;
  statistics: {
    mean: number;
    variance: number;
    trend: number;
  };
  ewsIndicators: {
    autocorrelation: number;
    variance: number;
    skewness: number;
  };
}
```

## Error Handling

All components and hooks implement standardized error handling:

```typescript
interface ErrorState {
  code: string;
  message: string;
  details?: unknown;
}
```

## Usage Examples

### Starting a Processing Job

```typescript
const { startProcessing, status } = useDataProcessing({
  location: "12.34,56.78",
  startDate: "2024-01-01",
  endDate: "2024-12-31",
  resolution: "10"
});

await startProcessing();
```

### Running Analysis

```typescript
const { analyze, results } = useAnalysis({
  dropOutliers: true,
  fillGaps: true,
  deseasonalize: true,
  smoothing: {
    enabled: true,
    window: 7
  }
});

await analyze();
```